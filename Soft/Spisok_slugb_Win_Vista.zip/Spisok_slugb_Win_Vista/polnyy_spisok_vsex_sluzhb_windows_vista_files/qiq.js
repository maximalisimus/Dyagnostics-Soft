/** global */
var rtn4p_item          = 7083;
var rtn4p_show_src      = 0;
var rtn4p_show_desc     = 0;
var rtn4p_show_photo    = 1;
var rtn4p_show_align    = 'left';
/** styles */
var rtn4p_class_title   = 'rttitle';
var rtn4p_class_src     = '';
var rtn4p_class_desc    = 'rtdesc';
var rtn4p_class_photo   = '';

/** styles */
var rtn4p_style_photo   = 'margin:2px;width: 85px; height: 85px;';
/** header/footer */
var rtn4p_header        = '<table width="100%" cellspacing="5" cellpadding="0" border="0" style=""><tr>';
var rtn4p_footer        = '</tr></table>';
/** news line */
var rtn4p_line_before   = '<td valign="top" align="center" width="25%" style="padding: 7px 10px 7px 10px;border:solid 1px #E5E5E5;">';
var rtn4p_line_after    = '</td>';

var rtn4p_title_before  = '<div style="padding: 2px 0px 2px 0px;">';
var rtn4p_title_after   = '</div>';

var rtn4p_desc_before   = '<br style="font-size: 2px">';
var rtn4p_desc_after    = '';

var rtn4p_photo_before    = '<table cellspacing="0" cellpadding="0" style="border:solid 1px #E5E5E5;background-color: #FFFFFF;margin:0px 0px 0px 0px;"><tr><td align="center">';
var rtn4p_photo_after     = '</td></tr></table>';

var rtn4p_src_before    = '';
var rtn4p_src_after     = '';


var rtn4p_domain        = 'http://ru.redtram.com/';
var rtn4p_host          = 'http://n4p.ru.redtram.com/';
var rtn4p_photo         = 'http://img2.ru.redtram.com/news/';
var rtn4p_page          = 1;

var rtn4p_data          = '';
var rtn4p_css_styles    = 'a.rttitle:link,a.rttitle:visited{font-family: Verdana;color: #4682B4; font-size: 11px; font-weight: bold; text-decoration: underline;letter-spacing: -1px;}a.rttitle:active,a.rttitle:hover{color: #4F5C64;text-decoration: underline;}a.rtdesc:link,a.rtdesc:visited{font-family: Verdana;color: #000000; font-size: 10px; font-weight: normal; text-decoration: none;letter-spacing: -1px;}a.rtdesc:active, a.rtdesc:hover{text-decoration: none;}';

var rtn4p_initid        = 'rtn4p_img_len1';

/** do not edit */
function getCookie(name){var dc=document.cookie;var prefix=name+"=";var begin=dc.indexOf("; "+prefix);if(begin==-1){begin=dc.indexOf(prefix);if(begin!=0){return null;}}else{begin += 2;}var end=dc.indexOf(";", begin);if (end==-1){end=dc.length;}return unescape(dc.substring(begin+prefix.length,end));}
function setCookie(name,value,expires,path,domain,secure){document.cookie=name+"="+escape(value)+((expires)?"; expires="+expires.toGMTString():"")+((path)?"; path="+path:"")+((domain)?";domain="+domain:"")+((secure)?"; secure":"");}
function RedTramCookies(value){var cn="rtn4p";if(value){rtn4p_page=value;}else{var c=getCookie(cn);if(c!=null&&parseInt(c)<=10&&(parseInt(c)+1)<=10){rtn4p_page=parseInt(c)+1;}setCookie(cn,rtn4p_page,"","/");}}RedTramCookies();

var rtn4p_init          = document.getElementById(rtn4p_initid);

function RedTramI(){if(rtn4p_init){rtn4p_init.innerHTML = rtn4p_data;}}
function RedTramH(){rtn4p_data+=rtn4p_header;}
function RedTramF(){rtn4p_data+=rtn4p_footer;RedTramI();}
function RedTramAdd(title,url,src,desc,photo,special){
if (desc.length>80){
        desc = desc.substr(0,80)+'...';
     }else{
        desc = desc+'...'
     }
    str=rtn4p_line_before;
    if(rtn4p_show_src){str+=rtn4p_src_before+'<a target="_blank" href="'+rtn4p_domain+'sources/'+src+'/"'+(rtn4p_class_src?' class="'+rtn4p_class_src+'"':'')+'>'+src+'<'+'/a>'+rtn4p_src_after;}
    if(rtn4p_show_photo&&photo!=''){str+=rtn4p_photo_before+'<a target="_blank" href="'+rtn4p_domain+'go/'+url+'/n4p/'+rtn4p_item+'/"><img'+(rtn4p_class_photo?' class="'+rtn4p_class_photo+'"':'')+' src="'+rtn4p_photo+''+photo+'" border=0 align="'+rtn4p_show_align+'"'+(rtn4p_style_photo?' style="'+rtn4p_style_photo+'"':'')+' /><'+'/a>'+rtn4p_photo_after;}
    str+=rtn4p_title_before+'<a target="_blank" href="'+rtn4p_domain+'go/'+url+'/n4p/'+rtn4p_item+'/"'+(rtn4p_class_title?' class="'+rtn4p_class_title+'"':'')+'>'+title+'<'+'/a>'+rtn4p_title_after;
    if(rtn4p_show_desc&&desc!=''){str+=rtn4p_desc_before+'<a target="_blank" href="'+rtn4p_domain+'go/'+url+'/n4p/'+rtn4p_item+'/"'+(rtn4p_class_desc?' class="'+rtn4p_class_desc+'"':'')+'>'+desc+'<'+'/a>'+rtn4p_desc_after;}
    rtn4p_data+=str+rtn4p_line_after;
}
if (rtn4p_init) {
    document.write('<style type="text/css">'+rtn4p_css_styles+'<'+'/style>');
    document.write('<scr'+'ipt language="javascript" type="text/javascript" src="'+rtn4p_host+'?i='+rtn4p_item+'&p='+rtn4p_page+'"><'+'/scr'+'ipt>');
}